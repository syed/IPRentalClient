'''
Created on 27-Nov-2011

@author: syedah
'''
from suds.client import Client

class IPrentalClient:
    key = None
    password = None
    username = None
   
    wsdl = 'https://secure.iprental.com/protocols/4.0/public_api.php?wsdl'
    
    def __init__(self,username , password ,key):
        self.username = username
        self.password = password
        self.key = key
        self.client = Client(self.wsdl)
        print self.client
        
    def get_proxy(self):
            resp = self.client.service.PublicAPI(self.key,self.username,self.password, '4.0' , '0' , '' )
            if resp['Response'] > 0 :
                print "Auth Failure" 
            return resp
                
    
if __name__ == '__main__' :
    key = 'e7792f28-c8e7-485c-a64c-1c78a4f725fb'
    username = 'greatvivek@gmail.com'
    password = 'Cosco007@'
    cl = IPrentalClient(username,password,key)
    res= cl.get_proxy()
    print res